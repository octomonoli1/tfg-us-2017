﻿/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","pt",{title:"Informação do elemento",dialogName:"Nome da janela de diálogo",tabName:"Nome do separador",elementId:"ID do elemento",elementType:"Tipo de Elemento"});