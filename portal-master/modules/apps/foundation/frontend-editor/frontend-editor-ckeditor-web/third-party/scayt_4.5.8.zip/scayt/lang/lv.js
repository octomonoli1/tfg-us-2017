﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'lv', {
	btn_about: 'Par SCAYT',
	btn_dictionaries: 'Vārdnīcas',
	btn_disable: 'Atslēgt SCAYT',
	btn_enable: 'Ieslēgt SCAYT',
	btn_langs:'Valodas',
	btn_options: 'Uzstādījumi',
	text_title:  'Pārbaudīt gramatiku rakstot'
});
