﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'nl', {
	btnIgnore: 'Negeren',
	btnIgnoreAll: 'Alles negeren',
	btnReplace: 'Vervangen',
	btnReplaceAll: 'Alles vervangen',
	btnUndo: 'Ongedaan maken',
	changeTo: 'Wijzig in',
	errorLoading: 'Er is een fout opgetreden bij het laden van de dienst: %s.',
	ieSpellDownload: 'De spellingscontrole is niet geïnstalleerd. Wilt u deze nu downloaden?',
	manyChanges: 'Klaar met spellingscontrole: %1 woorden aangepast',
	noChanges: 'Klaar met spellingscontrole: geen woorden aangepast',
	noMispell: 'Klaar met spellingscontrole: geen fouten gevonden',
	noSuggestions: '- Geen suggesties -',
	notAvailable: 'Excuses, deze dienst is momenteel niet beschikbaar.',
	notInDic: 'Niet in het woordenboek',
	oneChange: 'Klaar met spellingscontrole: één woord aangepast',
	progress: 'Bezig met spellingscontrole...',
	title: 'Spellingscontrole',
	toolbar: 'Spellingscontrole'
});
