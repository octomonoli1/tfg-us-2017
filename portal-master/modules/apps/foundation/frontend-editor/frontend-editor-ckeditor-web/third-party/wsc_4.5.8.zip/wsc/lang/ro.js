﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'ro', {
	btnIgnore: 'Ignoră',
	btnIgnoreAll: 'Ignoră toate',
	btnReplace: 'Înlocuieşte',
	btnReplaceAll: 'Înlocuieşte tot',
	btnUndo: 'Starea anterioară (undo)',
	changeTo: 'Schimbă în',
	errorLoading: 'Eroare în lansarea aplicației service host %s.',
	ieSpellDownload: 'Unealta pentru verificat textul (Spell checker) neinstalată. Doriţi să o descărcaţi acum?',
	manyChanges: 'Verificarea textului terminată: 1% cuvinte modificate',
	noChanges: 'Verificarea textului terminată: Niciun cuvânt modificat',
	noMispell: 'Verificarea textului terminată: Nicio greşeală găsită',
	noSuggestions: '- Fără sugestii -',
	notAvailable: 'Scuzați, dar serviciul nu este disponibil momentan.',
	notInDic: 'Nu e în dicţionar',
	oneChange: 'Verificarea textului terminată: Un cuvânt modificat',
	progress: 'Verificarea textului în desfăşurare...',
	title: 'Spell Checker',
	toolbar: 'Verifică scrierea textului'
});
