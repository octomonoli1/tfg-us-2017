﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'cy', {
	btnIgnore: 'Anwybyddu Un',
	btnIgnoreAll: 'Anwybyddu Pob',
	btnReplace: 'Amnewid Un',
	btnReplaceAll: 'Amnewid Pob',
	btnUndo: 'Dadwneud',
	changeTo: 'Newid i',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'Gwirydd sillafu heb ei arsefydlu. A ydych am ei lawrlwytho nawr?',
	manyChanges: 'Gwirio sillafu wedi gorffen: Newidiwyd %1 gair',
	noChanges: 'Gwirio sillafu wedi gorffen: Dim newidiadau',
	noMispell: 'Gwirio sillafu wedi gorffen: Dim camsillaf.',
	noSuggestions: '- Dim awgrymiadau -',
	notAvailable: 'Nid yw\'r gwasanaeth hwn ar gael yn bresennol.',
	notInDic: 'Nid i\'w gael yn y geiriadur',
	oneChange: 'Gwirio sillafu wedi gorffen: Newidiwyd 1 gair',
	progress: 'Gwirio sillafu yn ar y gweill...',
	title: 'Gwirio Sillafu',
	toolbar: 'Gwirio Sillafu'
});
