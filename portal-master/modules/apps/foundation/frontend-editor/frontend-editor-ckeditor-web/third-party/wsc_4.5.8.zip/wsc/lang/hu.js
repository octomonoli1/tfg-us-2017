﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'hu', {
	btnIgnore: 'Kihagyja',
	btnIgnoreAll: 'Mindet kihagyja',
	btnReplace: 'Csere',
	btnReplaceAll: 'Összes cseréje',
	btnUndo: 'Visszavonás',
	changeTo: 'Módosítás',
	errorLoading: 'Hiba a szolgáltatás host betöltése közben: %s.',
	ieSpellDownload: 'A helyesírás-ellenőrző nincs telepítve. Szeretné letölteni most?',
	manyChanges: 'Helyesírás-ellenőrzés kész: %1 szó cserélve',
	noChanges: 'Helyesírás-ellenőrzés kész: Nincs változtatott szó',
	noMispell: 'Helyesírás-ellenőrzés kész: Nem találtam hibát',
	noSuggestions: 'Nincs javaslat',
	notAvailable: 'Sajnálom, de a szolgáltatás jelenleg nem elérhető.',
	notInDic: 'Nincs a szótárban',
	oneChange: 'Helyesírás-ellenőrzés kész: Egy szó cserélve',
	progress: 'Helyesírás-ellenőrzés folyamatban...',
	title: 'Helyesírás ellenörző',
	toolbar: 'Helyesírás-ellenőrzés'
});
